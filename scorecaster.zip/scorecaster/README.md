# SCORECASTER 🏆

Urheiluennustaja joka hakee tiedot automaattisesti ESPN:stä.

## Deployaus Verceliin (ilmainen, 2 minuuttia)

### Vaihtoehto A — GitHub + Vercel (suositeltu)

1. Mene **github.com** → kirjaudu tai luo tili
2. Paina **New repository** → anna nimeksi `scorecaster` → Create
3. Lataa tiedostot GitHubiin (drag & drop "uploading an existing file")
4. Mene **vercel.com** → kirjaudu GitHubilla
5. Paina **New Project** → valitse `scorecaster` repo → **Deploy**
6. Valmis! Saat linkin joka toimii kaikkialla 🎉

### Vaihtoehto B — Vercel CLI

```bash
npm i -g vercel
cd scorecaster
vercel
```

## Rakenne

```
scorecaster/
├── api/
│   ├── games.js        # Hakee päivän pelit ESPN:stä
│   └── teamstats.js    # Hakee joukkueen viimeiset 5 peliä
├── public/
│   └── index.html      # Frontend
└── vercel.json         # Vercel konfiguraatio
```

## Toiminta

1. **HAE PELIT** → `/api/games` hakee ESPN:stä tämän päivän ottelut
2. Klikkaa ottelua → `/api/teamstats` hakee molempien joukkueiden tilastot
3. Valitse tekijät → **Analysoi** → Poisson-malli laskee ennusteen
