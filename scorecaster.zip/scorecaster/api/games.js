const https = require('https');

const SPORT_URLS = {
  soccer: [
    { url: 'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard', league: 'Premier League' },
    { url: 'https://site.api.espn.com/apis/site/v2/sports/soccer/esp.1/scoreboard', league: 'La Liga' },
    { url: 'https://site.api.espn.com/apis/site/v2/sports/soccer/ger.1/scoreboard', league: 'Bundesliga' },
    { url: 'https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard', league: 'Serie A' },
    { url: 'https://site.api.espn.com/apis/site/v2/sports/soccer/fra.1/scoreboard', league: 'Ligue 1' },
    { url: 'https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard', league: 'Champions League' },
  ],
  hockey: [
    { url: 'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard', league: 'NHL' },
  ],
  basketball: [
    { url: 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard', league: 'NBA' },
  ],
};

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(e); }
      });
    }).on('error', reject);
  });
}

function parseRecord(records) {
  if (!records || !records.length) return null;
  const rec = records.find(r => r.type === 'total' || r.type === 'overall') || records[0];
  if (!rec?.summary) return null;
  const parts = rec.summary.split('-').map(Number);
  if (parts.length === 2) return { w: parts[0], d: 0, l: parts[1] };
  if (parts.length === 3) return { w: parts[0], d: parts[1], l: parts[2] };
  return null;
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  const sport = req.query.sport || 'soccer';
  const urls = SPORT_URLS[sport] || SPORT_URLS.soccer;

  const now = new Date();
  const dateStr = [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, '0'),
    String(now.getDate()).padStart(2, '0'),
  ].join('');

  const allGames = [];

  await Promise.allSettled(urls.map(async ({ url, league }) => {
    try {
      const data = await fetchJson(`${url}?dates=${dateStr}`);
      (data.events || []).forEach(ev => {
        const comp = ev.competitions?.[0];
        if (!comp) return;
        const home = comp.competitors?.find(c => c.homeAway === 'home');
        const away = comp.competitors?.find(c => c.homeAway === 'away');
        if (!home || !away) return;

        const hRec = parseRecord(home.records);
        const aRec = parseRecord(away.records);

        // Parse avg goals from statistics
        const getStat = (stats, name) => {
          const s = (stats || []).find(x => x.name === name || x.abbreviation === name);
          return s ? parseFloat(s.displayValue || s.value || 0) : null;
        };

        allGames.push({
          id: ev.id,
          league,
          leagueSlug: url.split('/sports/')[1]?.split('/scoreboard')[0],
          homeName: home.team.displayName || home.team.name,
          awayName: away.team.displayName || away.team.name,
          homeId: home.team.id,
          awayId: away.team.id,
          time: comp.date ? new Date(comp.date).toLocaleTimeString('fi-FI', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Helsinki' }) : 'TBA',
          status: comp.status?.type?.state || 'pre',
          hRec, aRec,
          hGoalsFor:  getStat(home.statistics, 'pointsPerGame') || getStat(home.statistics, 'goalsPerGame'),
          hGoalsAgainst: getStat(home.statistics, 'pointsAllowedPerGame') || getStat(home.statistics, 'goalsAllowedPerGame'),
          aGoalsFor:  getStat(away.statistics, 'pointsPerGame') || getStat(away.statistics, 'goalsPerGame'),
          aGoalsAgainst: getStat(away.statistics, 'pointsAllowedPerGame') || getStat(away.statistics, 'goalsAllowedPerGame'),
        });
      });
    } catch (e) { /* skip */ }
  }));

  res.json({ games: allGames, date: dateStr });
};
