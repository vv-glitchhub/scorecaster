const https = require('https');

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(e); }
      });
    }).on('error', reject);
  });
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');

  const { leagueSlug, teamId } = req.query;
  if (!leagueSlug || !teamId) return res.json({ error: 'Missing params' });

  try {
    const url = `https://site.api.espn.com/apis/site/v2/sports/${leagueSlug}/teams/${teamId}/schedule`;
    const data = await fetchJson(url);

    const events = (data.events || [])
      .filter(e => e.competitions?.[0]?.status?.type?.state === 'post')
      .slice(-5);

    if (!events.length) return res.json(null);

    let w = 0, d = 0, l = 0, gf = 0, ga = 0;
    const form = [];

    events.forEach(ev => {
      const comp = ev.competitions[0];
      const me = comp.competitors.find(c => String(c.team?.id) === String(teamId));
      const opp = comp.competitors.find(c => String(c.team?.id) !== String(teamId));
      if (!me || !opp) return;
      const sf = parseInt(me.score) || 0;
      const sa = parseInt(opp.score) || 0;
      gf += sf; ga += sa;
      if (sf > sa) { w++; form.push('W'); }
      else if (sf === sa) { d++; form.push('D'); }
      else { l++; form.push('L'); }
    });

    const n = events.length || 1;
    res.json({
      w, d, l, n, gf, ga,
      avgF: +(gf / n).toFixed(2),
      avgA: +(ga / n).toFixed(2),
      form,
      wr: Math.round(w / n * 100),
    });
  } catch(e) {
    res.json(null);
  }
};
